import { TestBed } from '@angular/core/testing';

import { MeventService } from './mevent.service';

describe('MeventService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MeventService = TestBed.get(MeventService);
    expect(service).toBeTruthy();
  });
});
