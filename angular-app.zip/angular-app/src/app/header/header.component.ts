import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MeventService } from '../mevent.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  loginFlag:boolean =false;
  constructor(public mEventService: MeventService, public router: Router) {
    this.router.navigate(['/login']);
   }

  ngOnInit() {
    this.mEventService.mEvent.subscribe(()=>{
      this.loginFlag = true;
      this.router.navigate(['/']);
    })
  }

  logout(){
    this.loginFlag = false;
    this.router.navigate(['/login']);
  }

}
