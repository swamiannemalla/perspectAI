import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MeventService } from '../mevent.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(public fb: FormBuilder, public mEventService: MeventService) {
    this.loginForm=this.fb.group({
      username:[],
      password:[],
    })
   }
  loginForm:FormGroup;

  ngOnInit() {
  }
  login(){
    this.mEventService.riseEvent();
  }

}
