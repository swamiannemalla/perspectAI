import { Injectable, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MeventService {
  mEvent = new Subject();
  constructor() { }
  riseEvent(){
    this.mEvent.next();
  }
  
}
